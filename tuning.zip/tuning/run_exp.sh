#!/bin/bash

# Experiment folder (relative path)
e_folder="~/evorobotpy2/environments/xdpole"

# Which .ini file to use?
ini_name="ErDpoleCMA.ini"

# How many seeds do you want to run for each experiment?
number_of_seeds=1

#How many experiments do you want to run simultaneously?
simultaneously=1

#Seed initial number
initial_seed_number=1

total_of_processes=$((number_of_seeds))

commands_list=()

seed=$initial_seed_number

for ((n=0;n<number_of_seeds;n++)); do
	find_folder="cd ${e_folder}"
	seed_command="python3 ~/evorobotpy2/bin/es.py -f ${ini_name}"
	seed_command="${seed_command} -s ${seed}"
	new_command=("$find_folder" "$seed_command")
	commands_list+=("$new_command")
	((seed++))
done

run_process() {
    eval "${1} && ${2}"
}

export -f run_process

parallel --jobs "${simultaneously}" run_process ::: "${commands_list[@]}"

arquivo="seeds_$(date +%Y-%m-%d).txt"
echo "${ini_name}" >> "${arquivo}"
for command in "${commands_list[@]}"; do
    echo "${command[1]}" >> "${arquivo}"
done
